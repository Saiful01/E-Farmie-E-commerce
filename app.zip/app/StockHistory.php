<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StockHistory extends Model
{
    public $timestamps=true;
    protected $guarded=[];
}
