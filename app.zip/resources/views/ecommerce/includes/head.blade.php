<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<title>@yield('title')</title>
<!-- Favicon Icon -->
<link rel="icon" type="image/png" href="/ecommerce/img/favicon.png">
<!-- Bootstrap core CSS -->
<link href="/ecommerce/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!-- Material Design Icons -->
<link href="/ecommerce/vendor/icons/css/materialdesignicons.min.css" media="all" rel="stylesheet" type="text/css"/>
<!-- Select2 CSS -->
<link href="/ecommerce/vendor/select2/css/select2-bootstrap.css"/>
<link href="/ecommerce/vendor/select2/css/select2.min.css" rel="stylesheet"/>
<!-- Custom styles for this template -->
<link href="/ecommerce/css/osahan.min.css" rel="stylesheet">
<!-- Owl Carousel -->
<link rel="stylesheet" href="/ecommerce/vendor/owl-carousel/owl.carousel.css">
<link rel="stylesheet" href="/ecommerce/vendor/owl-carousel/owl.theme.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css"
      integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
<link href="/admin/assets/css/icons.css" rel="stylesheet" type="text/css">
