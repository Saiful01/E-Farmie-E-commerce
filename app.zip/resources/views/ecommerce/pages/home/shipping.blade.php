<div class="shipping-area">
    <div class="container">
        <div class="row">

            <div class="col-md-4 right-border">
                <div class="row shipping">
                    <div class="col-6">
                        <i class="fa fa-phone"></i>
                    </div>
                    <div class="col-6">
                        <p class="shipping-title">০১৮৮০-০৬০৯০৯</p>
                        <p> হটলাইন নাম্বার</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 right-border">
                <div class="row shipping">
                    <div class="col-6">
                        <i class="fa fa-envelope"></i>
                    </div>
                    <div class="col-6">
                        <p class="shipping-title">kenarhat@gmail.com</p>
                        <p>ইমেইল</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="row shipping">
                    <div class="col-6">
                        <i class="fa fa-calendar"></i>
                    </div>
                    <div class="col-6">
                        <p class="shipping-title">শনি- শুক্র{{-- / ৮.০- ১০.০--}}</p>
                        <p>সেবাদান সময়</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>