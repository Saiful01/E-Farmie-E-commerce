<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from colorlib.com/preview/theme/farmie/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Mar 2020 14:27:47 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <title><?php echo $__env->yieldContent('title'); ?></title>

    <link rel="icon" href="/farmie/img/core-img/favicon.ico">

    <link rel="stylesheet" href="/farmie/css/custom.css">
    <link rel="stylesheet" href="/farmie/css/style.css">
    <link rel="stylesheet" href="/farmie/css/animate.css">
    <link rel="stylesheet" href="/farmie/css/bootstrap.min.css">
    <link rel="stylesheet" href="/farmie/css/classy-nav.css">
    <link rel="stylesheet" href="/farmie/css/font-awesome.min.css">
    <link rel="stylesheet" href="/farmie/css/magnific-popup.css">
    <link rel="stylesheet" href="/farmie/css/owl.carousel.min.css">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>


</head>
<body>

<div class="preloader d-flex align-items-center justify-content-center">
    <div class="spinner"></div>
</div>

<header class="header-area">

    <div class="top-header-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="top-header-content d-flex align-items-center justify-content-between">

                        <div class="top-header-meta">
                            <p>ফার্মিতে আপনাকে স্বাগতম, আমরা আশা করি আপনি আমাদের পণ্যগুলি উপভোগ করবেন এবং ভাল অভিজ্ঞতা অর্জন করবেন</p>
                        </div>

                        <div class="top-header-meta text-right">
                            <a href="#" data-toggle="tooltip" data-placement="bottom" title="abcd@gmail.com"><i class="fa fa-envelope-o" aria-hidden="true"></i> <span>
ই-মেইল: <span class="__cf_email__" data-cfemail="264f4840494243435445544347524f504366414b474f4a0845494b">[email&#160;protected]</span></span></a>
                            <a href="#" data-toggle="tooltip" data-placement="bottom" title="+1 234 122 122"><i class="fa fa-phone" aria-hidden="true"></i> <span>মোবাইল: +880-</span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="famie-main-menu">
        <div class="classy-nav-container breakpoint-off">
            <div class="container">

                <nav class="classy-navbar justify-content-between" id="famieNav">

                    <a href="index.html" class="nav-brand"><img src="/farmie/img/core-img/logo.png" alt=""></a>

                    <div class="classy-navbar-toggler">
                        <span class="navbarToggler"><span></span><span></span><span></span></span>
                    </div>

                    <div class="classy-menu">

                        <div class="classycloseIcon">
                            <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                        </div>

                        <div class="classynav">
                            <ul>
                                <li class="active"><a href="index.html">হোম</a></li>
                                <li><a href="about.html">আমাদের সম্পর্কে</a></li>




















                                <li><a href="our-product.html">আমাদের পণ্য</a></li>

                                <li><a href="#">সংবাদ</a></li>
                                <li><a href="contact.html">যোগাযোগ</a></li>
                            </ul>

                            <div id="searchIcon">
                                <i class="icon_search" aria-hidden="true"></i>
                            </div>










                            <a class="btn btn-success btn-sm ml-3 text-white" href="/customer/checkout">
                                <i class="fa fa-shopping-cart "></i> পণ্য

                            </a>

                                <ul class="">
                                    <li class="">
                                        <a class="" href="/customer/login">লগ-ইন</a>
                                    </li>
                                </ul>

                                <ul class="">
                                    <li class="">
                                        <a class="" href="/customer/registration">রেজিস্ট্রেশন </a>
                                    </li>
                                </ul>














                        </div>

                    </div>
                </nav>

                <div class="search-form">
                    <form action="#" method="get">
                        <input type="search" name="search" id="search" placeholder="Type keywords &amp; press enter...">
                        <button type="submit" class="d-none"></button>
                    </form>

                    <div class="closeIcon"><i class="fa fa-times" aria-hidden="true"></i></div>
                </div>
            </div>
        </div>
    </div>
</header>

<?php echo $__env->yieldContent('content'); ?>

<footer class="footer-area">

    <div class="main-footer bg-img bg-overlay section-padding-80-0" style="background-image: url(/farmie/img/bg-img/3.jpg);">
        <div class="container">
            <div class="row">

                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="footer-widget mb-80">
                        <a href="#" class="foo-logo d-block mb-30"><img src="/farmie/img/core-img/logo2.png" alt=""></a>
                        <p></p>
                        <div class="contact-info">
                            <p><i class="fa fa-map-pin" aria-hidden="true"></i><span>সেকশন: 14, মিরপুর রোড, ঢাকা</span></p>
                            <p><i class="fa fa-envelope" aria-hidden="true"></i><span><a href="https://colorlib.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="7910171f16571d1c1c0b1a0b1c180d100f1c391e14181015571a1614">[email&#160;protected]</a></span></p>
                            <p><i class="fa fa-phone" aria-hidden="true"></i><span>+880</span></p>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="footer-widget mb-80">
                        <h5 class="widget-title"></h5>

                        <nav class="footer-widget-nav">
                            <ul>












                            </ul>
                        </nav>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="footer-widget mb-80">
                        <h5 class="widget-title">সাম্প্রতিক খবর</h5>

                        <div class="single-recent-blog d-flex align-items-center">
                            <div class="post-thumbnail">
                                <img src="/farmie/img/bg-img/4.jpg" alt="">
                            </div>
                            <div class="post-content">
                                <a href="#" class="post-title">বাজারে ডাব্লুএর বৃহত্তম কৃষিকাজের ব্যবসা</a>
                                <div class="post-date">1 এপ্রিল 2020 </div>
                            </div>
                        </div>

                        <div class="single-recent-blog d-flex align-items-center">
                            <div class="post-thumbnail">
                                <img src="/farmie/img/bg-img/5.jpg" alt="">
                            </div>
                            <div class="post-content">
                                <a href="#" class="post-title">গরুর মাংসের খুচরা মূল্য রেকর্ডে চলেছে</a>
                                <div class="post-date">1 এপ্রিল 2020</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="footer-widget mb-80">
                        <h5 class="widget-title">যোগাযোগ রেখো</h5>

                        <div class="footer-social-info">
                            <a href="#">
                                <i class="fa fa-facebook" aria-hidden="true"></i>
                                <span>ফেসবুক</span>
                            </a>
                            <a href="#">
                                <i class="fa fa-twitter" aria-hidden="true"></i>
                                <span>টুইটার</span>
                            </a>
                            <a href="#">
                                <i class="fa fa-pinterest" aria-hidden="true"></i>
                                <span>ইউটিউব</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="copywrite-area">
        <div class="container">
            <div class="copywrite-text">
                <div class="row align-items-center">
                    <div class="col-md-6">




                    </div>
                    <div class="col-md-6">
                        <div class="footer-nav">
                            <nav>








                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>



<script src="/farmie/js/jquery.min.js" type="be202cbde170147cd96c3217-text/javascript"></script>

<script src="/farmie/js/popper.min.js" type="be202cbde170147cd96c3217-text/javascript"></script>

<script src="/farmie/js/bootstrap.min.js" type="be202cbde170147cd96c3217-text/javascript"></script>

<script src="/farmie/js/owl.carousel.min.js" type="be202cbde170147cd96c3217-text/javascript"></script>

<script src="/farmie/js/classynav.js" type="be202cbde170147cd96c3217-text/javascript"></script>

<script src="/farmie/js/wow.min.js" type="be202cbde170147cd96c3217-text/javascript"></script>

<script src="/farmie/js/jquery.sticky.js" type="be202cbde170147cd96c3217-text/javascript"></script>

<script src="/farmie/js/jquery.magnific-popup.min.js" type="be202cbde170147cd96c3217-text/javascript"></script>

<script src="/farmie/js/jquery.scrollup.min.js" type="be202cbde170147cd96c3217-text/javascript"></script>

<script src="/farmie/js/jarallax.min.js" type="be202cbde170147cd96c3217-text/javascript"></script>

<script src="/farmie/js/jarallax-video.min.js" type="be202cbde170147cd96c3217-text/javascript"></script>

<script src="/farmie/js/active.js" type="be202cbde170147cd96c3217-text/javascript"></script>

<script async src="/farmie/js/google.js" type="be202cbde170147cd96c3217-text/javascript"></script>
<script type="be202cbde170147cd96c3217-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
<script src="/farmie/js/rocket-loader.min.js" data-cf-settings="be202cbde170147cd96c3217-|49" defer=""></script>
</body>

<!-- Mirrored from colorlib.com/preview/theme/farmie/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Mar 2020 14:28:00 GMT -->
</html>
