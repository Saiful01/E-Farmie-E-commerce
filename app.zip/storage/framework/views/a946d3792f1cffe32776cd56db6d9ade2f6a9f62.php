<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>


    <div class="slider">
        <div class="container">
            <div class="row">

                <div class="col-md-5 mx-auto">

                    <div class="row">
                        <div class="col-md">
                            <?php if(session('success')): ?>
                                <div class="alert alert-success alert-dismissible">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong><?php echo e(session('success')); ?>!</strong>
                                </div>
                            <?php endif; ?>
                            <?php if(session('failed')): ?>
                                <div class="alert alert-danger alert-dismissible">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong><?php echo e(session('failed')); ?>!</strong>
                                </div>
                            <?php endif; ?>

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <div class="card">
                                <div class="col-md-6">
                                    <h5>লগ ইন</h5>
                                    <hr class="horizontal-line">
                                </div>
                                <div class="card-body">
                                    <form method="post" action="/customer/login-check" enctype="multipart/form-data"
                                           class="ng-pristine ng-valid">
                                    <div class="form-group required">
                                        <label for="input-payment-firstname" class="control-label">ফোন নাম্বার</label>
                                        <input type="text" class="form-control" id="firstname"
                                               name="customer_phone">
                                        <input class="form-control" type="hidden" name="_token"
                                               value="<?php echo e(csrf_token()); ?>" autocomplete="off">
                                    </div>
                                    <div class="form-group required">
                                        <label for="input-payment-lastname" class="control-label">পাসওয়ার্ড</label>
                                        <input type="text" class="form-control" id="input-payment-lastname"
                                               name="customer_password" >
                                    </div>

                                    <div class="pull-right">
                                        <button class="btn btn-success">লগ ইন</button>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>